#!/usr/bin/env python
# license removed for brevity
import rospy
from std_msgs.msg import Int64

def send_data():
    pub = rospy.Publisher('command_du_one', Int64, queue_size=10)
    rospy.init_node('test_command_send', anonymous=True)
    rate = rospy.Rate(10) # 10hz
    while not rospy.is_shutdown():
        hello_str = 311
        pub.publish(hello_str)
        rate.sleep()

if __name__ == '__main__':
    try:
        send_data()
    except rospy.ROSInterruptException:
        pass
