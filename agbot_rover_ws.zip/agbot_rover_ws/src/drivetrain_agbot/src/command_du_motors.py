#!/usr/bin/env python
import rospy
from std_msgs.msg import Int64

import rospy
import time
import serial


ser_drive_unit_1 = serial.Serial(
port='/dev/ttyACM0',
baudrate=115200,
parity=serial.PARITY_NONE,
stopbits=serial.STOPBITS_ONE,
bytesize=serial.EIGHTBITS,
timeout=1
)

def DriveUnit_1(val):
        payload1 = "!G 1 " + str(val) + "_"
        payload2 = "!G 2 " + str(val) + "_"
        ser_drive_unit_1.write(payload1)
        ser_drive_unit_1.write(payload2)


value_received = 0

def callback(data):
#	rospy.loginfo(data.data)
	value_received = data.data
#	print(value_received)

	DriveUnit_1(value_received)


def command_motors():
	rospy.init_node('command_du_one', anonymous=True)

	rospy.Subscriber("command_du_one", Int64, callback)
	rospy.spin()

if __name__ == '__main__':
    command_motors()
